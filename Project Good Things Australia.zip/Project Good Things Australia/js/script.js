(function($) {

  
    
    $(document).ready(function(){
      $('.single-item').slick({
        dots: true,
        arrows: false,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
       

      });
    });

    $(document).ready(function(){
        $('.product-item').slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            prevArrow:"<i class='fa fa-angle-left fa-2xl position-absolute top-50 start-0' aria-hidden='true' style='z-index:9999;'></i>",
            nextArrow:"<i class='fa fa-angle-right fa-2xl position-absolute top-50 end-0' aria-hidden='true'></i>",       
            //autoplay: true,
            autoplaySpeed: 2000,
            responsive: [              
              {
                breakpoint: 600,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              }
            ]  
        });
      });   

      $(document).ready(function(){
        $('.review-item').slick({
            slidesToShow: 3,
            dots: true,
            slidesToScroll: 3,
            prevArrow:"<i class='fa fa-angle-left fa-2xl position-absolute top-50 start-0' aria-hidden='true' style='z-index:9999;'></i>",
            nextArrow:"<i class='fa fa-angle-right fa-2xl position-absolute top-50 end-0' aria-hidden='true'></i>",       
            autoplay: true,
            infinite: true,
            autoplaySpeed: 2000,  
            responsive: [              
              {
                breakpoint: 600,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              }
            ]  
        });
      });   


      $(document).ready(function(){
        $('.testimonial-item').slick({
            slidesToShow: 1,
            dots: true,
            prevArrow:"<i class='fa fa-angle-left fa-2xl position-absolute top-50 start-0' aria-hidden='true' style='z-index:9999;'></i>",
            nextArrow:"<i class='fa fa-angle-right fa-2xl position-absolute top-50 end-0' aria-hidden='true'></i>",       
            autoplay: true,
            infinite: true,
            autoplaySpeed: 2000,  
        });
      });   
  
  
  
  

    $(document).ready(function(){
        $('.vert-single-item').slick({
          dots: false,
          arrows: false,
          infinite: true,
          speed: 300,
          slidesToShow: 1,
          slidesToScroll: 1, 
          autoplay: true,
          vertical: true,          
 
        });
      });     

})(jQuery);